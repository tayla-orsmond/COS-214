#include "ConfectioneryFactory.h"
//constructor
ConfectioneryFactory::ConfectioneryFactory(){
    std::cout<<"Confectionery Factory created!\n";
}
//destructor
ConfectioneryFactory::~ConfectioneryFactory(){
    std::cout<<"Confectionery Factory destroyed.\n";
}