#ifndef CLASS_C
#define CLASS_C

#include <iostream>
#include "ClassA.h"
using namespace std;
//Tayla Orsmond u21467456

class ClassC: public ClassA{
    public:
    ClassC();
    ~ClassC();
};

#endif