#ifndef CLASS_B
#define CLASS_B
//Tayla Orsmond u21467456

using namespace std;
class ClassB{
    public:
    ClassB();
    virtual ~ClassB();
};

#endif