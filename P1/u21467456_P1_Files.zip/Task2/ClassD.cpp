#include <iostream>
#include "ClassD.h"
using namespace std;
//Tayla Orsmond u21467456

ClassD::ClassD(){
    cout<< "ClassD's Empty Constructor is Called.\n";
}
ClassD::~ClassD(){
    cout<< "ClassD's Destructor is Called.\n";
}