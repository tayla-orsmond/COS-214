#include <iostream>
#include "ClassC.h"
using namespace std;
//Tayla Orsmond u21467456

ClassC::ClassC(){
    cout<< "ClassC's Empty Constructor is Called.\n";
}
ClassC::~ClassC(){
    cout<< "ClassC's Destructor is Called.\n";
}