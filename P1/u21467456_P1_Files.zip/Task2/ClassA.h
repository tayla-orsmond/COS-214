#ifndef CLASS_A
#define CLASS_A
//Tayla Orsmond u21467456
using namespace std;
class ClassA{
    public:
    ClassA();
    virtual ~ClassA() = 0; //to make class A abstract, it needs a pure virtual function
};

#endif