#include <iostream>
#include "ClassB.h"
using namespace std;
//Tayla Orsmond u21467456

ClassB::ClassB(){
    cout<< "ClassB's Empty Constructor is Called.\n";
}
ClassB::~ClassB(){
    cout<< "ClassB's Destructor is Called.\n";
}