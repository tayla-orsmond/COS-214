#ifndef CLASS_E
#define CLASS_E

#include <iostream>
#include "ClassD.h"
using namespace std;
//Tayla Orsmond u21467456

class ClassE: public ClassD{
    public:
    ClassE();
    ~ClassE();
};

#endif