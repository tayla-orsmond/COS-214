#include <iostream>
#include "ClassA.h"
using namespace std;
//Tayla Orsmond u21467456

ClassA::ClassA(){
    cout<< "ClassA's Empty Constructor is Called.\n";
}
ClassA::~ClassA(){
    cout<< "ClassA's Destructor is Called.\n";
}