#include <iostream>
#include "ClassE.h"
using namespace std;
//Tayla Orsmond u21467456

ClassE::ClassE(){
    cout<< "ClassE's Empty Constructor is Called.\n";
}
ClassE::~ClassE(){
    cout<< "ClassE's Destructor is Called.\n";
}